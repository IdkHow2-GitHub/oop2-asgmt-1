﻿using AltAsgmt1.Appliances;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace AltAsgmt1
{
    internal class Program
    {
       
        static void Main(string[] args)
        {
            ModernAppliances MmodernAppliances = new MyModernAppliances();
            MmodernAppliances.DisplayMenu();
            MmodernAppliances.ReadAllAppliances();
           

            while (true)
            {
                string optionInString = Console.ReadLine();
                int optionInInt = int.Parse(optionInString);

                if (optionInInt == 1)
                {
                    MmodernAppliances.checkOut();
                }else if (optionInInt == 2)
                {
                    MmodernAppliances.Find();
                }else if (optionInInt == 3)
                {
                    MmodernAppliances.DisplayType();

                }else if (optionInInt == 4)
                {
                    MmodernAppliances.randomList();

                }else if( optionInInt == 5)
                {
                    MmodernAppliances.Save();
                    break;
                }else
                {
                    Console.WriteLine("Invalid menu option!");
                    
                }
                MmodernAppliances.DisplayMenu();
            }
            Console.ReadKey();

        }
    }
}


  

