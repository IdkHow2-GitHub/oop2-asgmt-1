﻿using System;
using System.Collections;

namespace AltAsgmt1
{
    public class RandomComparer : ModernAppliances
    {
        public override void checkOut()
        {
            throw new NotImplementedException();
        }
        public override void DisplayDishwashers()
        {
            throw new NotImplementedException();
        }
        public override void DisplayMicrowave()
        {
            throw new NotImplementedException();
        }
        public override void DisplayRefrigirator()
        {
            throw new NotImplementedException();
        }
        public override void DisplayVacuums()
        {
            throw new NotImplementedException();
        }
        public override void Find()
        {
            throw new NotImplementedException();
        }
        public override void randomList()
        {
            Random random = new Random();
            Console.WriteLine("Enter number of appliances:\n");
            ArrayList all_prev_data_index = new ArrayList();
            string user_input = Console.ReadLine();
            Console.WriteLine("Random appliances:");
            for (int i = 0; i < int.Parse(user_input); i++)
            {
                int data_index = random.Next(AllAppliancesnew.Count);
                if (all_prev_data_index.Contains(data_index))
                {
                    data_index = random.Next(AllAppliancesnew.Count);
                    Console.WriteLine(AllAppliancesnew[data_index] + "\n");
                }
                else
                {
                    Console.WriteLine(AllAppliancesnew[data_index] + "\n");
                }
                if (all_prev_data_index.Count == AllAppliancesnew.Count)
                {
                    Console.WriteLine("All appliances have been shown. There are no more appliances.\n");
                    break;
                }
                else
                {
                    all_prev_data_index.Add(data_index);
                }
            }

        }
        }
        }

   
