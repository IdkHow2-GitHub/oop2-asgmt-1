﻿using AltAsgmt1.Appliances;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace AltAsgmt1
{
    public abstract class ModernAppliances
    {
        public void ReadAllAppliances()
        {
            using (StreamReader fileReader = new StreamReader("C:\\Users\\bsimm\\Desktop\\AltAsgmt1\\res\\appliances.txt"))
            {

                string lineReader;
                while ((lineReader = fileReader.ReadLine()) != null)
                {
                    string[] appliance_data = lineReader.Split(';');
                 

                    if (appliance_data[0][0] == '1')//refridgerator
                    {
                        refrigerator(long.Parse(appliance_data[0]), appliance_data[1], int.Parse(appliance_data[2]), decimal.Parse(appliance_data[3]), appliance_data[4], decimal.Parse(appliance_data[5]), short.Parse(appliance_data[6]), int.Parse(appliance_data[7]), int.Parse(appliance_data[8]));

                    }
                    else if (appliance_data[0][0] == '2')//vacuum
                    {
                        vacuum(long.Parse(appliance_data[0]), appliance_data[1], int.Parse(appliance_data[2]), decimal.Parse(appliance_data[3]), appliance_data[4], decimal.Parse(appliance_data[5]), appliance_data[6], short.Parse(appliance_data[7]));
                    }
                    else if (appliance_data[0][0] == '3')//microwave
                    {
                        microwave(long.Parse(appliance_data[0]), appliance_data[1], int.Parse(appliance_data[2]), decimal.Parse(appliance_data[3]), appliance_data[4], decimal.Parse(appliance_data[5]), float.Parse(appliance_data[6]), (appliance_data[7]));
                    }
                    else if (appliance_data[0][0] == '4' || appliance_data[0][0] == '5')//dishwasher
                    {
                        dishwasher(long.Parse(appliance_data[0]), appliance_data[1], int.Parse(appliance_data[2]), decimal.Parse(appliance_data[3]), appliance_data[4], decimal.Parse(appliance_data[5]), appliance_data[6], appliance_data[7]);
                    }
                    else
                    {
                        Console.WriteLine("Item not in system");
                    }
                }
            }

        }
        public List<Appliance> AllAppliancesnew = new List<Appliance>();

        public void refrigerator(long itemNumber, string brandName, int quantityAmount, decimal wattageAmount, string colorItem, decimal priceAmount, short doorAmount, int widthInch, int heightInch)
        {
            AllAppliancesnew.Add(new Refrigerator(itemNumber,brandName, quantityAmount,  wattageAmount,colorItem,  priceAmount, doorAmount,  widthInch, heightInch));
            

        }
        public void vacuum(long itemNumber, string brandName, int quantityAmount, decimal wattageAmount, string colorItem, decimal priceAmount, string gradeTotal, short battery_voltageAmount)
        {
            AllAppliancesnew.Add(new Vacuum(itemNumber, brandName, quantityAmount, wattageAmount, colorItem, priceAmount ,gradeTotal,  battery_voltageAmount));

        }
        public void microwave(long itemNumber, string brandName, int quantityAmount, decimal wattageAmount, string colorItem, decimal priceAmount, float capacityAmount, string room_typeString)
        {
            AllAppliancesnew.Add(new Microwave(itemNumber, brandName, quantityAmount, wattageAmount, colorItem, priceAmount,capacityAmount,room_typeString));

        }
        public void dishwasher(long itemNumber, string brandName, int quantityAmount, decimal wattageAmount, string colorItem, decimal priceAmount, string featureItem, string sound_ratingType)
        {
            AllAppliancesnew.Add(new Dishwasher(itemNumber, brandName, quantityAmount, wattageAmount, colorItem, priceAmount,featureItem,sound_ratingType));

        }


        public void DisplayMenu()
        {
            Console.WriteLine("Welcome!");
            Console.WriteLine("Please select a menu option!");
            Console.WriteLine("1: check out");
            Console.WriteLine("2: Find appliances by brand");
            Console.WriteLine("3: Display Appliances by type");
            Console.WriteLine("4: random appliance list");
            Console.WriteLine("5: Save and Exit");
            Console.WriteLine("Enter option: ");


        }

        public void DisplayType()
        {
            Console.WriteLine("Appliance Types");
            Console.WriteLine("1: Refrigerators");
            Console.WriteLine("2: Vacuums");
            Console.WriteLine("3: Microwaves");
            Console.WriteLine("4: Dishwashers");
            Console.WriteLine("Enter option: \n");
            string ApplianceTypeInString = Console.ReadLine();
            int applianceTypeNumber = int.Parse(ApplianceTypeInString);


            if (applianceTypeNumber == 1)
            {
                DisplayRefrigirator();
            }
            else if (applianceTypeNumber == 2)
            {
                DisplayVacuums();
            } else if (applianceTypeNumber == 3)
            {
                DisplayMicrowave();
            } else if (applianceTypeNumber == 4)
            {
                DisplayDishwashers();
            }
            else
            {
                Console.WriteLine("Invalid Type");
            }
        }

        public abstract void DisplayRefrigirator();
        public abstract void DisplayVacuums();
        public abstract void DisplayMicrowave();
        public abstract void DisplayDishwashers();

        public abstract void checkOut();
        public abstract void Find();
        public abstract void randomList();
        public void DisplayAppliancesFromList(List<Appliance> appliances, int max)
        {
            if (appliances.Count > 0)
            {
                Console.WriteLine("Found appliances:");
                Console.WriteLine();
                int numberCount = 0;
                foreach (Appliance apps in appliances)
                {
                    Console.WriteLine($"{apps}\n");
                    numberCount++;
                    if (max > 0 && numberCount >= max)
                    {
                        break;
                    }
                }
            }
            else
            {
                Console.WriteLine("No appliances found.");
            }

            Console.WriteLine();
        }
        public void Save()
        {

            Console.Write("Saving...");
            string filePath = "C:\\Users\\ivanl\\source\\repos\\oop2-asgmt-1\\AltAsgmt1\\appliances.txt";
            using (StreamWriter files = File.CreateText(filePath))
            {
                foreach (var appliance in AllAppliancesnew)
                {
                    files.WriteLine(appliance.formatFromFile());
                }

                files.Close();

                Console.WriteLine("Saving Done");
            }
        }


    }

}
