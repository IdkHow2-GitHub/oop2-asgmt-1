﻿using AltAsgmt1.Appliances;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using AltAsgmt1;
using System.Collections;


namespace AltAsgmt1
{
    public class MyModernAppliances : ModernAppliances
    {
        public override void DisplayVacuums()
        {
            Console.WriteLine("Possible options: ");
            Console.WriteLine("0 - Any");
            Console.WriteLine("1 - Residential");
            Console.WriteLine("2 - Commercial");
            Console.Write("Enter grade: ");
            string gradeInput = Console.ReadLine();

            string grade = "";
            if (gradeInput == "0")
            {
                grade = "Any";
            }else if(gradeInput == "1")
            {
                grade = "Residential";
            }else if(gradeInput == "2")
            {
                grade = "Commercial";
            }
            else
            {
                Console.WriteLine("Invalid option");
                return;
            }

            Console.WriteLine("Possible options: ");
            Console.WriteLine("0 - Any");
            Console.WriteLine("1 - 18 Volt");
            Console.WriteLine("2 - 24 Volt");
            Console.Write("Enter voltage: ");
            string voltageInput = Console.ReadLine();
            short voltageAmount = 0;
            if (voltageInput == "0")
            {
                voltageAmount = 0;
            } else if (voltageInput == "1")
            {
                voltageAmount = 18;
            } else if (voltageInput == "2") 
            {
                voltageAmount = 24;
            }
            else
            {
                Console.WriteLine("Invalid Option!");
                return;
            }

            List<Appliance> found = new List<Appliance>();

            foreach (var itemAppliance in AllAppliancesnew)
            {
                if (itemAppliance is Vacuum vacuum && (grade == "Any" || vacuum.grade == grade))
                {
                    if((grade == "Any" || vacuum.grade == grade) && (voltageAmount == 0 || vacuum.battery_voltage == voltageAmount))
                    {
                        found.Add(itemAppliance);

                    }
                }
            }
            
            DisplayAppliancesFromList(found, 0);

        }
        public override void checkOut()
        {
            Console.WriteLine("Enter the item number of an appliance: ");
            string iteminstring = Console.ReadLine();
            Console.WriteLine();

            long ItemNumber = long.Parse(iteminstring);

            int itemCheck = 0;
            string officialItemNumber = "";
            foreach (var appliance in AllAppliancesnew)
            {
                if (appliance.item_number == ItemNumber && appliance.IsAvailable)
                {
                    appliance.checkOut();
                    itemCheck = 1;
                    officialItemNumber = appliance.item_number.ToString();
                    break;
                }
                else if (appliance.item_number == ItemNumber && appliance.IsAvailable == false)
                {
                    itemCheck = 2;
                    break;
                }
                else
                {
                    itemCheck = 4;
                }

            }
            if (itemCheck == 1)
            {
                Console.WriteLine($"Appliance {officialItemNumber} has been chcecked out. \n");
            }
            else if (itemCheck == 2)
            {
                Console.WriteLine("Item is not available...");
            }
            else
            {
                Console.WriteLine("Not an item in the system!");
            }
        }

        public override void DisplayDishwashers()
        {
            Console.WriteLine("Possible options: ");
            Console.WriteLine("0 - Any");
            Console.WriteLine("1 - Quietest");
            Console.WriteLine("2 - Quieter");
            Console.WriteLine("3 - Quiet");
            Console.WriteLine("4 - Moderate");
            Console.Write("Enter sound rating: ");
            string soundRating = Console.ReadLine();
            Console.WriteLine();


            string soundratingConverted = "";
            if (soundRating == "0")
            {
                soundratingConverted = "Any";
            }
            else if( soundRating == "1") 
            {
                soundratingConverted = "Qt";
            }
            else if (soundRating == "2")
            {
                soundratingConverted = "Qr";
            }
            else if (soundRating == "3")
            {
                soundratingConverted = "Qu";
            }
            else if (soundRating == "4")
            {
                soundratingConverted = "M";
            }else
            {
                Console.WriteLine("Invalid Sound rating!");
                return;
            }

            List<Appliance> found = new List<Appliance>();
            foreach(var itemAppliance in AllAppliancesnew)
            {
                if (itemAppliance is Dishwasher dishwasher && (soundratingConverted == "Any" || dishwasher.sound_rating == soundratingConverted))
                {
                    found.Add(itemAppliance);
                }
            }

            DisplayAppliancesFromList(found, 0);
        }

        public override void DisplayMicrowave()
        {
            Console.WriteLine("Possible options: ");
            Console.WriteLine("0 - Any");
            Console.WriteLine("1 - Kitchen");
            Console.WriteLine("2 - Work site");
            Console.Write("Enter room type: ");
            string roomType = Console.ReadLine();
            Console.WriteLine();
            string assigneedRoomType = "";
            
            if (roomType == "0")
            {
                assigneedRoomType = "A";
            }
            else if (roomType == "1")
            {
                assigneedRoomType = "K";
            }
            else if (roomType == "2")
            {
               assigneedRoomType= "W";
            }
            else
            {
                Console.WriteLine("Invalid option!");
                return;
            }

            List<Appliance> found = new List<Appliance>();
            foreach (var itemAppliance in AllAppliancesnew)
            {
                if (itemAppliance is Microwave microwave && (assigneedRoomType == "A" || microwave.room_type == assigneedRoomType))
                {
                    found.Add(itemAppliance);
                }
            }
            DisplayAppliancesFromList(found, 0);

        }
        public override void Find()
        {
            Console.WriteLine("Enter brand name to search for: ");
            string BrandToSearch = Console.ReadLine();
            Console.WriteLine();


            int foundBrand = 0;

            for (int i = 0; i < AllAppliancesnew.Count; i++)
            {
                if (BrandToSearch == AllAppliancesnew[i].brand)
                {
                    Console.WriteLine("Matching Appliances");
                    Console.WriteLine($"{AllAppliancesnew[i].ToString()} \n");
                    foundBrand += 1;
                }
            }

            if (foundBrand == 0)
            {
                Console.WriteLine($"Appliance not found: {BrandToSearch}");

            }

        }

        public override void DisplayRefrigirator()
        {
            Console.WriteLine("Possible options:");
            Console.WriteLine("0 - Any");
            Console.WriteLine("2 - Double doors");
            Console.WriteLine("3 - Three doors");
            Console.WriteLine("4 - Four doors");
            Console.Write("Enter number of doors: ");

            string doorsInString = Console.ReadLine();
            Console.WriteLine();

            int doors = int.Parse(doorsInString);
          

            List<Appliance> found = new List<Appliance>();
            foreach (var itemAppliance in AllAppliancesnew)
            {
                if (itemAppliance is Refrigerator refrigerator && (doors == 0 || refrigerator.door == doors))
                {
                    found.Add(itemAppliance);
                }
            }
            DisplayAppliancesFromList(found, 0);
        }
        public override void randomList()
        {
            Random random = new Random();
            Console.WriteLine("Enter number of appliances:\n");
            ArrayList all_prev_data_index = new ArrayList();
            string user_input = Console.ReadLine();
            Console.WriteLine("Random appliances:");
            for (int i = 0; i < int.Parse(user_input); i++)
            {
                int data_index = random.Next(AllAppliancesnew.Count);
                if (all_prev_data_index.Contains(data_index))
                {
                    data_index = random.Next(AllAppliancesnew.Count);
                    Console.WriteLine(AllAppliancesnew[data_index] + "\n");
                }
                else
                {
                    Console.WriteLine(AllAppliancesnew[data_index] + "\n");
                }
                if (all_prev_data_index.Count == AllAppliancesnew.Count)
                {
                    Console.WriteLine("All appliances have been shown. There are no more appliances.\n");
                    break;
                }
                else
                {
                    all_prev_data_index.Add(data_index);
                }
            }
        }
    }  
}

//    Console.WriteLine("Appliance Types:");
//    Console.WriteLine("0 - Any");
//    Console.WriteLine("1 – Refrigerators");
//    Console.WriteLine("2 – Vacuums");
//    Console.WriteLine("3 – Microwaves");
//    Console.WriteLine("4 – Dishwashers");
//    Console.Write("Enter type of appliance: ");
//    string type = Console.ReadLine();
//    Console.WriteLine();

//    Console.Write("Enter number of appliances: ");

//    string numInString = Console.ReadLine();
//    int num = int.Parse(numInString);
//    if (num <0)
//    {
//        Console.WriteLine("Invalid number!");
//        return;
//    }


//    List<Appliance> found = new List<Appliance>();

//    foreach(var  itemAppliance in AllAppliancesnew)
//    {
//        if (type == "0")
//        {
//            found.Add(itemAppliance);
//        }
//        else if (type == "1" && itemAppliance is Refrigerator)
//        {
//            found.Add(itemAppliance);
//        }
//        else if (type == "2" && itemAppliance is Vacuum)
//        {
//            found.Add(itemAppliance);
//        }
//        else if (type == "3" && itemAppliance is Microwave)
//        {
//            found.Add(itemAppliance);
//        }
//        else if (type == "4" && itemAppliance is Dishwasher)
//        {
//            found.Add(itemAppliance);
//        }
//    }


//    //Random random = new Random();
//    //found.Sort((a, b) => random.Next(-1, 2));
//    found.Sort(randomApplianceList());

//    DisplayAppliancesFromList(found, num);
//}

